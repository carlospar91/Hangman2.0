/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangmanproject;

/**
 *
 * @author CARLOSPARLOUR
 */
public class HangmanDriver {
    
     public static void main(String[] args) {
        //
//        String[] myStringArray = new String[55000];
//        String rand_word;
//        
//        System.out.println("CHoose a topic");
//        //This simulated a player choosing a file 
//        String choice = "Random";
//        String choosen = location(choice);
//        System.out.println(choosen);
        
     }
    
    
}
